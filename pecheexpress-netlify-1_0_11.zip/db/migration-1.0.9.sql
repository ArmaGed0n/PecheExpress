-- Pêche Express 1.0.9 — profil de pêcheur personnalisable.
-- À exécuter UNE FOIS dans la console SQL de Neon si tu as déjà installé le classement (1.0.4 à 1.0.8).
-- Aucune donnée existante n'est supprimée.
ALTER TABLE leaderboard_players ADD COLUMN IF NOT EXISTS public_id UUID NOT NULL DEFAULT gen_random_uuid();
ALTER TABLE leaderboard_players ADD COLUMN IF NOT EXISTS profile JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE leaderboard_players ADD COLUMN IF NOT EXISTS profile_updated_at TIMESTAMPTZ;
CREATE UNIQUE INDEX IF NOT EXISTS leaderboard_players_public_id_idx ON leaderboard_players (public_id);
